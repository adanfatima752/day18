# Create a dictionary with some key-value pairs
my_dict = {'a': 10, 'b': 20, 'c': 30}

# Print the dictionary before the update
print("Dictionary before update:", my_dict)

# Update the value of a specific key
my_dict['b'] = 50

# Print the dictionary after the update
print("Dictionary after update:", my_dict)
