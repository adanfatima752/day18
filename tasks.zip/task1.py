# Create an empty dictionary
my_dict = {}

# Add three key-value pairs to the dictionary
my_dict['key1'] = 'value1'
my_dict['key2'] = 'value2'
my_dict['key3'] = 'value3'

# Print the dictionary
print(my_dict)
