def merge_dicts(dict1, dict2):
    # Create a new dictionary with the contents of dict1
    merged_dict = dict1.copy()
    
    # Update the new dictionary with items from dict2
    merged_dict.update(dict2)
    
    # Print the resulting merged dictionary
    print("Merged Dictionary:", merged_dict)

# Example usage:
dict1 = {'a': 1, 'b': 2, 'c': 3}
dict2 = {'b': 20, 'c': 30, 'd': 40}

merge_dicts(dict1, dict2)
