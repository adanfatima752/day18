def print_keys_and_values(dictionary):
    # Get the list of keys
    keys = list(dictionary.keys())
    
    # Get the list of values
    values = list(dictionary.values())
    
    # Print the lists
    print("Keys:", keys)
    print("Values:", values)

# Example usage:
my_dict = {'a': 10, 'b': 20, 'c': 30}
print_keys_and_values(my_dict)
