def get_value(dictionary, key):
    # Use the get method with a default value of 0
    value = dictionary.get(key, 0)
    print(f"The value for '{key}' is: {value}")

# Example usage:
my_dict = {'a': 10, 'b': 20, 'c': 30}

# Retrieve and print value for an existing key
get_value(my_dict, 'b')  # Should print: The value for 'b' is: 20

# Retrieve and print value for a non-existing key
get_value(my_dict, 'd')  # Should print: The value for 'd' is: 0
