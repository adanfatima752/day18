# Create a nested dictionary with information about multiple students
students = {
    'student1': {
        'name': 'Alice',
        'age': 20,
        'grades': {
            'Math': 90,
            'Science': 85,
            'English': 88
        }
    },
    'student2': {
        'name': 'Bob',
        'age': 22,
        'grades': {
            'Math': 75,
            'Science': 80,
            'English': 78
        }
    },
    'student3': {
        'name': 'Charlie',
        'age': 21,
        'grades': {
            'Math': 95,
            'Science': 90,
            'English': 92
        }
    }
}

# Print the nested dictionary
print("Student Information:")
for student_id, info in students.items():
    print(f"\n{student_id}:")
    print(f"  Name: {info['name']}")
    print(f"  Age: {info['age']}")
    print("  Grades:")
    for subject, grade in info['grades'].items():
        print(f"    {subject}: {grade}")
