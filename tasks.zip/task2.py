def print_value_for_key(dictionary, key):
    if key in dictionary:
        print(f"The value for '{key}' is: {dictionary[key]}")
    else:
        print(f"Key '{key}' not found in the dictionary.")

# Example usage:
my_dict = {'a': 10, 'b': 20, 'c': 30}
print_value_for_key(my_dict, 'b')  # Should print: The value for 'b' is: 20
print_value_for_key(my_dict, 'd')  # Should print: Key 'd' not found in the dictionary.
