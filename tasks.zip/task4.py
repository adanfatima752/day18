from collections import defaultdict

# Read a line of text from the user
text = input("Enter a line of text: ")

# Initialize an empty dictionary to store word counts
word_count = defaultdict(int)

# Split the text into words
words = text.split()

# Count the occurrences of each word
for word in words:
    word_count[word] += 1

# Convert defaultdict to a regular dictionary for printing
word_count_dict = dict(word_count)

# Print the dictionary of word counts
print("Word counts:", word_count_dict)
