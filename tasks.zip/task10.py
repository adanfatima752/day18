from collections import Counter
import re

def most_common_word(filename):
    # Open and read the file
    with open(filename, 'r') as file:
        text = file.read().lower()  # Convert to lowercase to ensure case-insensitive counting
    
    # Use regular expressions to find words, ignoring punctuation
    words = re.findall(r'\b\w+\b', text)
    
    # Count the occurrences of each word
    word_counts = Counter(words)
    
    # Find the word with the highest count
    if word_counts:
        most_common = word_counts.most_common(1)[0]
        word, count = most_common
        print(f"The most common word is '{word}' with a count of {count}.")
    else:
        print("No words found in the file.")

# Example usage:
filename = 'example.txt'
most_common_word(filename)
